import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
public class Main{
	
	public static void main(String args[])
		throws IOException
		{
	//System.out.println("Running!");
	
		System.out.println("Search for something or not I guess if you don't wanna:\n");
		// Enter data using BufferReader
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(System.in));

        // Reading data using readLine
        String searchThing = reader.readLine();
		
		
		SearchForADoc thingy1 = new SearchForADoc("ArticleDatabase.txt");
		//System.out.println("Running!");
		SearchForAWord thingy2 = new SearchForAWord(searchThing, "synList.txt");
		//System.out.println("Running!");
		ArrayList<Article> artsyfartsy = thingy1.createArt();
		//System.out.println(artsyfartsy);
		thingy2.search(artsyfartsy);
		System.out.println("type the EXACT article title's first word if you'd like to expand :)");
		String title = reader.readLine();
		for (Article art: artsyfartsy){
			if(art.getName().indexOf(title) != -1){
				System.out.println(art.getContents());
			}
		}
		
		
		
	}
}
