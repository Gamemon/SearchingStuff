public class Main{
	public void main(String args[]){
	
		SearchForADoc thingy1 = SearchForADoc("tester.txt");
		SearchForAWord thingy2 = SearchForAWord("fish", "synList");
		
		thingy2.search(thingy1.createArt());
		
		
		
	}
}
